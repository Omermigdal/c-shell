#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#define STR_SEP " \t\n"

int main()
{
    char line[1024];
    char *args[100];
    // main loop of the shell
    while (1)
    {
        printf(">> ");
        fflush(stdout);

        // Read input line
        if (fgets(line, 1024, stdin) == NULL)
        {
            break;
        }

        // Tokenize input
        args[0] = strtok(line, STR_SEP);
        int i = 0;
        while (args[i] != NULL)
        {
            ++i;
            args[i] = strtok(NULL, STR_SEP);
        }

        // Check if last argument is "&" (run in background)
        if (strcmp(args[i - 1], "&") == 0)
        {
            args[i - 1] = NULL; // remove '&' from args
        }
        pid_t pid;
        int status;

        if ((pid = fork()) < 0)
        {

            printf("ERROR: forking child process failed\n");
            exit(1);
        }
        else if (pid == 0)
        {
            if (execvp(args[0], args) < 0)
            {
                printf("ERROR: exec child process failed\n");
                exit(1);
            }
        }
        else
        {
            while (wait(&status) != pid)
                ;
        }
    }

    return 0;
}