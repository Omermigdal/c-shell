#!/bin/bash

#a. creating a folder named after first argument
mkdir "$1";
cd "$1"


#b. redirecting the echo desired into a txt file
echo "Hello ${USER}, I am Omer Migdal" > hello.txt

#c. copying the file given as second argument to the current folder , then compiling  to myexe
cp "$2" . ;
gcc "$(basename "$2")" -Wall -o myexe

#d. print the number of lines of third argument file
wc -l < "$3"

#e. print all the files from the user (home) directory
ls -la ~