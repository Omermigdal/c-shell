#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

#define MAX_ARGS 64
#define MAX_BG_PROCS 100

pid_t bg_pids[MAX_BG_PROCS];
int bg_count = 0;

int parse_input(char *input, char **args)
{
    char *token = strtok(input, " ");
    int i = 0;

    while (token && i < MAX_ARGS - 1)
    {
        args[i++] = token;
        token = strtok(NULL, " ");
    }
    args[i] = NULL;
    return i;
}

int is_background(char **args)
{
    if (!args[0])
        return 0;
    int i = 0;
    while (args[i + 1])
        i++;
    return (strcmp(args[i], "&") == 0);
}

void remove_background_operator(char **args)
{
    int i = 0;
    while (args[i + 1])
        i++;
    args[i] = NULL;
}

void track_background_process(pid_t pid)
{
    if (bg_count < MAX_BG_PROCS)
    {
        bg_pids[bg_count++] = pid;
        printf("[BG Start] PID %d\n", pid);
    }
    else
    {
        fprintf(stderr, "Background process limit reached\n");
    }
}

void check_completed_processes()
{
    for (int i = 0; i < bg_count;)
    {
        int status;
        pid_t result = waitpid(bg_pids[i], &status, WNOHANG);

        if (result > 0)
        {
            printf("[BG Done] PID %d exited with status %d\n",
                   bg_pids[i], WEXITSTATUS(status));
            bg_pids[i] = bg_pids[--bg_count];
        }
        else
        {
            i++;
        }
    }
}

void execute_command(char **args, int bg)
{
    pid_t pid = fork();

    if (pid == 0)
    { // Child
        execvp(args[0], args);
        perror("execvp failed");
        exit(EXIT_FAILURE);
    }
    else if (pid > 0)
    { // Parent
        if (bg)
        {
            track_background_process(pid);
        }
        else
        {
            waitpid(pid, NULL, 0);
        }
    }
    else
    {
        perror("fork failed");
    }
}

int main()
{
    char input[256];
    char *args[MAX_ARGS];

    signal(SIGINT, SIG_IGN); // Ignore Ctrl+C in shell

    while (1)
    {
        check_completed_processes();
        printf("mysh> ");

        if (!fgets(input, sizeof(input), stdin))
            break;
        input[strcspn(input, "\n")] = 0;

        if (parse_input(input, args) == 0)
            continue;

        if (strcmp(args[0], "exit") == 0)
            break;

        int bg = is_background(args);
        if (bg)
            remove_background_operator(args);

        execute_command(args, bg);
    }

    return 0;
}
