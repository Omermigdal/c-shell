#include <stdio.h>

int main() {
    printf("Hello from source.c!\n");
    return 0;
}
