import sys
import tarfile
from os import path

hw_files = ["myscript.sh", "myshell.c", "myanswers.pdf"]

if (len(sys.argv) != 2):
	sys.exit("Usage: python checksub.py <submission-file>")
filename = sys.argv[1]

if not path.exists(filename):
	sys.exit(f"ERROR: '{filename}' does not exist")
if not filename.endswith(".tar.gz"):
	sys.exit(f"ERROR: '{filename}' is not a tar.gz file (doesn't end with .tar.gz)")
if (len(filename) != 16) or (not filename[:9].isdigit()):
	sys.exit(f"ERROR: '{filename}' should be named as: <9-digit-id>.tar.gz")

try:
	with tarfile.open(filename, 'r') as tar:
		for f in tar.getmembers():
			if f.isdir():
				sys.exit(f"ERROR: '{filename}' should not contain directories ({f.name})")
			if f.name.startswith('.'):
				sys.exit(f"ERROR: '{filename}' should not contain hidden/temp files ({f.name})")
			if not f.name in hw_files:
				sys.exit(f"ERROR: Invalid file in '{filename}' ({f.name})")
			else:
				hw_files.remove(f.name)

		if hw_files:
			sys.exit(f"ERROR: Missing files in '{filename}' ({','.join(hw_files)})")

		print(f"Success!")
		print(f"Your submission is correct IF:")
		print(f"\t- Your ID is {filename[:9]}")
		print(f"\t- Your code compiles successfully with NO WARNINGS")
except Exception as ex:
	sys.exit(f"ERROR: Can't access '{filename}' ({ex})")
